/* Greg Patterson (grpatter)
	A290
*/
struct node {
  struct node *next;/*hold a ptr to the next node */
  struct node *prev;/*hold a ptr to the previous node */
  char *last_nm;/*hold the last name */
  char *first_nm;/*hold the first name */
};
