#include "myprintf.c"
int main(){
  printint(12);
  printf("\n");
  printhex(-9199);
  printf("\n");
 return 0;
}
