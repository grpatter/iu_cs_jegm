#include <stdio.h>
#include <ctype.h>

int main()
{
  char ch;

  ch = getChar();

  printf("%c",ch);
}
