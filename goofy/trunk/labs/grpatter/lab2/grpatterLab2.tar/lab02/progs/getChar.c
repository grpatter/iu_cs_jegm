#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
  char c;
  int word = 0;
  int chars = 0;
  int lines = 0;
  
  while( (c = getchar()) != EOF)
    {
      chars++;
      if(c==' '){
	  word++;
	}
      if(c=='\n'){
	word++;
	lines++;
      }
    }
  printf("%d Lines %d Words %d Chars.\n", lines, word, chars);
}
