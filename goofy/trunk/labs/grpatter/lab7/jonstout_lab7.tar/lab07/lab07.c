#include <stdio.h>
#include "channel.h"

int msg = -1;
int stop = 0;

int message_handler()
{
  static int data;
  Begin();
  while (1)
    {
      Receive(msg, data);
      putchar(data);
    }
}

int message_decoder()
{
  unsigned int message = 0;
  int zero;
  int one;
  int totalBits = 0;

  static char previous;
  static char c;

  Begin();
  while ((c = getchar()) != EOF)
    {
      // process the character
      if ( c == '0' ){
	zero ++;
	previous = c;
      }
      if (c == '1'){
	if(previous == '0'){
	  // Check if there are more zero or one values
	  if (zero > one){
	    if(totalBits != 0){
	      printf("0");
	      message = message << 1;
	    }
	  }
	  else{
	    message = ((message << 1)|0x01);
	    printf("1");
	  }
	  zero = 0;
	  one = 1;
	  previous = c;
	  totalBits++;
	}
	else{
	  one++;
	  previous = c;
	}
      }
      if (zero > 30 && c == '1' && previous == '0'){
	//Send(msg, message);
	message = 0;
	zero = 0;
	one = 1;
	totalBits = 0;
      }

      if ( totalBits == 8){
	//Send(msg, message);
	printf(" %X ", message);
	message = 0;
	zero = 0;
	one = 0;
	totalBits = 0;
      }
    }
  stop = -1;
}

int main()
{
  
  while (!stop)
    {
      message_decoder();
      message_handler();
    }
  return 0;
}
