void push(int datum);
int pop();
void makeEmptyStack();
bool isEmptyStack();
int peek();
