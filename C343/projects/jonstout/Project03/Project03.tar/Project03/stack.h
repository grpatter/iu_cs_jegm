#include "AVAIL.h"

void push(QueueData datum);
QueueData pop();
void makeEmptyStack();
bool isEmptyStack();
QueueData peek();
