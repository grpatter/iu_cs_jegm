/*
** stack.h
** Greg Patterson (grpatter at indiana dot edu)
** 9/22/2009
*/

void push(int datum);
int pop();
void makeEmptyStack();
bool isEmptyStack();
int peek();
