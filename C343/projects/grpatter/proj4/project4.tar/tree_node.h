typedef struct{
	int data;
	int parent;
	bool visited;
} node;
