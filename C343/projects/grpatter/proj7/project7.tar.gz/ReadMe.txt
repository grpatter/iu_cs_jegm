// Project 7, C343: Data Structures, Indiana University
// File: ReadMe.txt
// Name: Greg Patterson, grpatter
// Date: 11/03/2009

Thoughts: Not sure the output (formatting) is as desired, but the specifications were a bit lacking in that regard.

Tag is used as a information field internally to make operations easier.
Distance is a struct to retain distnace information for ease of access later (idea was initially to save extra cycles).

Known Issues: None that I know of.