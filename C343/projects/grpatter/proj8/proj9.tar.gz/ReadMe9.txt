// Project 9, C343: Data Structures, Indiana University
// File: ReadMe.txt
// Name: Greg Patterson, grpatter
// Date: 12/04/2009

Thoughts: Seems to be working correctly.