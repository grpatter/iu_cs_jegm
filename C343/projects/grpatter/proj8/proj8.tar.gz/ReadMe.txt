// Project 8, C343: Data Structures, Indiana University
// File: ReadMe.txt
// Name: Greg Patterson, grpatter
// Date: 11/17/2009

Thoughts: Go as far as implementing the loops to copy, but it seriously mangled my data so I backed those changes out. I've become extremely sick
and cant afford to spend any more time on this right now. I hope to come back to it later this week whenever I feel a bit better.
The inserts use the symbol table idea and lookups/relationships are still kept in tact. There is some code + psuedocode representing my lines of thinking.
