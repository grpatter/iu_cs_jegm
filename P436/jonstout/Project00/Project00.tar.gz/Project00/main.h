#include "constants.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int find(char*, char);
void copy(char*, char*);
void ypoc(char*, char*);

typedef struct {
  char array[SIZE];
} a;

struct a;

